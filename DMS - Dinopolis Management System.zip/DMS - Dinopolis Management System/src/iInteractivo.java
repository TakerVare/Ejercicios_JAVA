public interface iInteractivo {

    public void mostrarInformacion();
    public void atraccionEstrella();
}
