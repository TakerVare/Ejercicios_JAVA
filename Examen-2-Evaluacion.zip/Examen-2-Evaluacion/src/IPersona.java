import java.util.*;
public interface IPersona {
    public String getNombre();

    public Date getFechaNacimiento();

    public String getPais();

    public int getDni();
}
